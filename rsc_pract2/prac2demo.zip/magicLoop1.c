/* Practical 2 - control sturcture and iterations
   Do you think the following will cause an infinite loop ?
   */
#include <stdio.h>
int main(){
  	short i;
	for (i=0;i <  10 ; i--) {
		printf("%d\n", i);
	}
}
