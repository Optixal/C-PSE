/* Practical 2 :
   What will be the output of the following program ?
*/
#include <stdio.h>
int main(){
  	float f;
	for (f = 0; f !=  2.0 ; f=f+0.1) {
		printf("%f\n", f);
	}
}
